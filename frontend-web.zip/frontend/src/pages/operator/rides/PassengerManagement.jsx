export { default } from "../PassengerManagement";
