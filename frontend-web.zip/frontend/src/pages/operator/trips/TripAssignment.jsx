export { default } from "../TripAssignment";
