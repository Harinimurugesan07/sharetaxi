export { default } from "../TripDetail";
