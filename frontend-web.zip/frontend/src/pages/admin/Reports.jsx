import { useEffect, useState } from "react";

import {
  Users,
  UserRound,
  ShieldCheck,
  Car,
  Route,
} from "lucide-react";

import Card from "../../components/Card";

import {
  LoadingState,
  ErrorState,
} from "../../components/States";

import { formatCurrency } from "../../lib/format";

import {
  adminDashboard,
  adminFinancialSummary,
} from "../../api/admin";

import "./Reports.css";

export default function Reports() {
  const [stats, setStats] = useState(null);
  const [status, setStatus] = useState("loading");

  const load = () => {
    setStatus("loading");

    Promise.all([
      adminDashboard(),
      adminFinancialSummary(),
    ])
      .then(([dashboard, financial]) => {
        setStats({
          ...dashboard,
          financial,
        });

        setStatus("success");
      })
      .catch(() => setStatus("error"));
  };

  useEffect(load, []);

  if (status === "loading") {
    return <LoadingState label="Building report..." />;
  }

  if (status === "error") {
    return <ErrorState onRetry={load} />;
  }

  const tiles = [
    {
      label: "Total Users",
      value: stats?.total_users,
      icon: Users,
      tone: "blue",
    },
    {
      label: "Total Drivers",
      value: stats?.total_drivers,
      icon: UserRound,
      tone: "purple",
    },
    {
      label: "Verified Drivers",
      value: stats?.verified_drivers,
      icon: ShieldCheck,
      tone: "green",
    },
    {
      label: "Total Vehicles",
      value: stats?.total_vehicles,
      icon: Car,
      tone: "amber",
    },
    {
      label: "Total Trips",
      value: stats?.total_trips,
      icon: Route,
      tone: "cyan",
    },
  ];

  const financial = stats?.financial || {};

  const financialTiles = [
    {
      label: "Total Ride Revenue",
      value: financial.total_ride_revenue,
      tone: "blue",
    },
    {
      label: "Admin Revenue",
      value: financial.total_admin_amount,
      tone: "purple",
    },
    {
      label: "Operator Share",
      value: financial.total_operator_share,
      tone: "amber",
    },
    {
      label: "Driver Earnings",
      value: financial.total_driver_earnings,
      tone: "green",
    },
  ];

  return (
    <Card className="reports-card">
      <p className="reports-title">
        Platform Summary
      </p>

      <p className="reports-subtitle">
        A snapshot of ShareTaxi activity across the platform.
      </p>

      <div className="reports-grid">
        {tiles.map(
          ({ label, value, icon: Icon, tone }) => (
            <div
              key={label}
              className={`reports-tile reports-tile-${tone}`}
            >
              <span className="reports-tile-icon">
                <Icon size={18} />
              </span>

              <span className="reports-tile-value">
                {value ?? "—"}
              </span>

              <span className="reports-tile-label">
                {label}
              </span>
            </div>
          )
        )}
      </div>

      <div className="reports-grid">
        {financialTiles.map(
          ({ label, value, tone }) => (
            <div
              key={label}
              className={`reports-tile reports-tile-${tone}`}
            >
              <span className="reports-tile-value">
                {formatCurrency(value ?? 0)}
              </span>

              <span className="reports-tile-label">
                {label}
              </span>
            </div>
          )
        )}
      </div>
    </Card>
  );
}